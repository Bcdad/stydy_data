#!/usr/bin/env python

__version__ = '2.2.0'
__license__ = 'BSD 3-Clause'
