#pragma once
#include "syntax.hh"

void repl(DefineStmt* stmt);
