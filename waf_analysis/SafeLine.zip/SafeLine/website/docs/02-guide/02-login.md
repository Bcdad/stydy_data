---
title: "登录雷池"
---

# 登录雷池

浏览器打开后台管理页面 `https://<waf-ip>:9443`。根据界面提示，使用 **支持 TOTP 的认证软件或者小程序** 扫描二维码，然后输入动态口令登录：

![login.gif](https://waf-ce.chaitin.cn/images/gif/login.gif)
